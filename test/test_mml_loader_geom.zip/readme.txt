

JAKELUTIEDOSTON SIS�LT� 
=======================

Vektorimuotoisilla tiedostoilla jakelutiedoston sis�lt� on seuraava:

- tietotuoteseloste
- datatiedosto

Katso skeemadokumentti: 
http://xml.nls.fi/Kuntajako/Asiakasdokumentaatio/Skeemakuvaus/NLSF_AU_schema_documentation_4.0.html


Rasterimuotoisilla tiedostoilla jakelutiedoston sis�lt� on seuraava:

- tietotuoteseloste
- datatiedosto
- asemointitiedosto


THE CONTENT OF THE DELIVERY FILE
================================

For vector data:

- data product document, in finnish
- data file

See schema documentation: 
http://xml.nls.fi/Kuntajako/Asiakasdokumentaatio/Skeemakuvaus/NLSF_AU_schema_documentation_4.0.html


For raster data:

- data product document, in finnish
- data file
- orientation file